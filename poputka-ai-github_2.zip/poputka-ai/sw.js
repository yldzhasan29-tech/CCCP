/* ==========================================================
   Service worker — офлайн-режим PWA.
   Оболочка приложения кешируется целиком: без сети открывается
   и работает всё, кроме тайлов карты и запросов к модели ИИ.
   ========================================================== */
const CACHE = 'poputka-v2';
const SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './assets/icon-192.png',
  './assets/icon-512.png',
  './styles/tokens.css',
  './styles/base.css',
  './styles/components.css',
  './styles/views.css',
  './src/util.js',
  './src/locales/ru.js',
  './src/locales/tr.js',
  './src/locales/en.js',
  './src/locales/zh.js',
  './src/locales/es.js',
  './src/locales/es419.js',
  './src/locales/pt.js',
  './src/locales/ar.js',
  './src/i18n.js',
  './src/places.js',
  './src/legal.js',
  './src/store.js',
  './src/seed.js',
  './src/ai.js',
  './src/matching.js',
  './src/map.js',
  './src/ui.js',
  './src/views/auth.js',
  './src/views/home.js',
  './src/views/publish.js',
  './src/views/search.js',
  './src/views/ride.js',
  './src/views/chats.js',
  './src/views/trips.js',
  './src/views/profile.js',
  './src/views/settings.js',
  './src/views/admin.js',
  './src/views/notifications.js',
  './src/views/legal.js',
  './src/shell.js',
  './src/main.js',
  './assets/favicon.svg'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE)
      .then((c) => c.addAll(SHELL).catch(() => undefined))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  /* тайлы карты и вызовы модели через кеш не гоняем */
  if (url.hostname.includes('tile.openstreetmap.org') ||
      url.hostname.includes('api.groq.com') ||
      url.hostname.includes('generativelanguage.googleapis.com')) return;

  /* свой origin: сначала кеш, потом сеть; ответ кладём в кеш */
  if (url.origin === self.location.origin) {
    e.respondWith(
      caches.match(req).then((hit) => {
        const net = fetch(req).then((res) => {
          if (res && res.status === 200 && res.type === 'basic') {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        }).catch(() => hit);
        return hit || net;
      })
    );
    return;
  }

  /* шрифты и прочее с других доменов — сеть с откатом в кеш */
  e.respondWith(fetch(req).catch(() => caches.match(req)));
});
