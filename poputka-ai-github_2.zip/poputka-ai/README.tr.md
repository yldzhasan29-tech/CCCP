<div align="center">

<img src="assets/favicon.svg" width="72" alt="Poputka AI" />

# Попутка ИИ · Poputka AI

**UrFU öğrencileri için şehir ↔ Novokoltsovski kampüsü akıllı araç paylaşımı**

UrFU «ТОП ИИ» hackathonu · Кейс 10

[![Pages](https://img.shields.io/badge/yay%C4%B1n-GitHub%20Pages-2b3137?logo=github)](../../deployments)
[![No build](https://img.shields.io/badge/build-gerekmiyor-12B886)](#-çalıştırma-30-saniye)
[![Zero deps](https://img.shields.io/badge/ba%C4%9F%C4%B1ml%C4%B1l%C4%B1k-0-4B37E0)](#-mimari)
[![i18n](https://img.shields.io/badge/dil-8-6B57F6)](#diller)
[![PWA](https://img.shields.io/badge/PWA-çevrimdışı-0BA5EC)](#-özellikler)
[![License](https://img.shields.io/badge/lisans-MIT-lightgrey)](LICENSE)

[Русский README →](README.md)

<img src="docs/screenshots/01-home.jpg" width="880" alt="Ana sayfa" />

</div>

---

## Nedir

UrFU öğrencilerinin kampüse birlikte gitmesini sağlayan bir web uygulaması.
Sürücü ilanını **normal cümlelerle** yazıyor — yapay zekâ bunu yapılandırılmış bir yolculuğa çeviriyor.
Yolcu arama yapıyor, **her önerinin neden önerildiğinin açıklamasıyla** eşleşme listesi alıyor ve
**her mesajın karşı tarafın diline otomatik çevrildiği** bir sohbette anlaşıyor.

Novokoltsovski kampüsü onlarca ülkeden öğrenci barındırıyor; dil engeli burada süs değil,
gerçek bir problem. Ürünün çekirdeği de bu.

---

## 🚀 Çalıştırma (30 saniye)

Ne `npm install`, ne build, ne bağımlılık.

```bash
git clone https://github.com/<organizasyon>/<depo>.git
cd <depo>
python3 -m http.server 8000
```

<http://localhost:8000> adresini aç.

Ya da doğrudan **`index.html` dosyasına çift tıkla** — dosyadan da çalışır.

> İnternet yalnızca OpenStreetMap karoları ve web fontu için gerekli.
> İnternet yokken uygulama **çökmez**: harita şematik moda düşer, güzergâh ve duraklar görünmeye devam eder.

---

## 🌐 Yayına alma

### GitHub Pages (workflow hazır)

Depoda [`.github/workflows/pages.yml`](.github/workflows/pages.yml) var. Bir kez açman yeterli:

**Settings → Pages → Build and deployment → Source: `GitHub Actions`**

Bundan sonra `main` dalına her push, siteyi
`https://<organizasyon>.github.io/<depo>/` adresinde otomatik günceller.

### Diğer seçenekler

| Platform | Ne yapılır |
|---|---|
| **Netlify** | klasörü <https://app.netlify.com/drop> sayfasına sürükle-bırak |
| **Vercel** | `vercel --prod` (statik proje, build komutu boş) |

---

## ✨ Özellikler

### Yolculuk ve eşleştirme

| | Özellik | Nerede |
|---|---|---|
| 🪄 | **Doğal dil çözümleme.** «Uralmaş'tan 8:30'da çıkıyorum, iki kişi alabilirim» → nokta, saat, koltuk, ücret | `İlan ver` |
| 🎯 | **Eşleştirme** güzergâh, saat ve güven puanına göre; yüzdelik eşleşme halkası | `Yolculuk bul` |
| 💬 | **«Bu yolculuk neden» açıklaması** — şablonla, modele gitmeden: anında ve öngörülebilir | karttaki buton |
| 🎚 | **Filtreler**: ücret, bagaj, sigara içilmeyen yolculuk, engelli erişimi, kadın yolculukları | `Yolculuk bul` |
| 🧭 | **Buluşma noktası ve yolda geçen süre**, yolculuk durumu: planlandı, yolda, gecikiyor, iptal, tamamlandı | yolculuk kartı |
| 🗺 | **Harita** OpenStreetMap karolarıyla — kütüphanesiz, kendi implementasyonumuz | her yerde |

### İletişim ve itibar

| | Özellik | Nerede |
|---|---|---|
| 🌍 | **Sohbette çeviri.** Her mesaj hem orijinal hem okuyanın dilinde | `Sohbetler` |
| ⭐ | **Karşılıklı puanlama** 1–5 yıldız + yorum | `Yolculuklarım → Tamamlanan` |
| 🛡 | **Güven seviyesi**: yolculuk sayısı, ortalama puan ve profil doluluğundan hesaplanır | profil, arama |
| 🚗 | **Doğrulanmış sürücü** — ehliyet, plaka ve araç bilgisinin öz-beyanı | `Ayarlar` |
| 🔔 | **Bildirimler**: rezervasyon, onay, red, iptal, yaklaşan kalkış hatırlatması | şapkadaki zil |

### Güvenlik ve moderasyon

| | Özellik | Nerede |
|---|---|---|
| 🆘 | **SOS butonu** — 112/102/103, kampüs güvenliği ve kendi acil durum kişileriniz | sabit buton |
| 👪 | **Acil durum kişileri**: ad, telefon ve yakınlık derecesi, en fazla beş kişi | `Ayarlar` |
| 🔒 | **Telefon ve buluşma noktası**, sürücü rezervasyonu onaylayana kadar gizli | yolculuk kartı |
| 👩 | **Kadın yolculukları**: yalnızca kadın sürücü açabilir, yalnızca kadınlar görüp rezerve edebilir | `İlan ver`, `Yolculuk bul` |
| 🚩 | **Şikayet ve kişisel engelleme** — engellediğiniz kişilerin ilanları aramanızda çıkmaz | profil, yolculuk kartı |
| ⚖️ | **Yasaklar**: uyarı → geçici → kalıcı; gerekçe, süre ve itiraz hakkıyla | yönetim paneli |
| 🗄 | **Yönetim paneli**: kullanıcılar, şikayetler, yasaklar, yöneticiler, güzergâhlar, işlem kaydı | `#/admin` |
| 🔑 | **İki kurucu** (kodda sabit) ve ayrı yetkilerle en fazla beş yönetici | `Yöneticiler` |
| 📓 | **Yönetici işlem kaydını** yalnızca kurucular görebilir | `İşlem kaydı` |

### Platform

| | Özellik |
|---|---|
| 🛡 | `@stud.urfu.ru` ile öğrenci doğrulaması (kurucu hesapları istisna) |
| 📱 | Tam responsive ve **PWA**: telefona kurulur, çevrimdışı açılır |
| 💾 | «Beni hatırla»: oturum ya sekme kapanınca silinir ya da kalıcı olur |
| 📄 | Gizlilik politikası, kullanım şartları, sorumluluk sınırları, topluluk kuralları |
| ✈️ | Ekranın ayrı bir köşesinde UrFU Telegram grubuna bağlantı |

### Diller

Rusça (varsayılan) · Türkçe · English · 中文 · Español · Español (LatAm) · Português · **العربية tam RTL desteğiyle**

Geçiş anında, sayfa yenilenmeden. Arapça'da düzen tamamen aynalanıyor —
navigasyon, kartlar, sohbet, harita, yönetim paneli. 8 çeviri dosyasının hepsi
aynı anahtar setini içeriyor; bu CI'da denetleniyor.

---

## 📸 Ekranlar

<table>
<tr>
<td width="50%"><img src="docs/screenshots/02-search.jpg" alt="Arama ve eşleştirme" /><br /><sub><b>Açıklamalı eşleştirme.</b> Yüzdelik skor ve gerekçe: saat, güzergâh, sürücü puanı.</sub></td>
<td width="50%"><img src="docs/screenshots/04-chat.jpg" alt="Çevirili sohbet" /><br /><sub><b>Otomatik çevirili sohbet.</b> Üstte orijinal, altta okuyanın dilindeki çeviri.</sub></td>
</tr>
<tr>
<td><img src="docs/screenshots/05-chat-rtl.jpg" alt="Arapça arayüz, RTL" /><br /><sub><b>Arapça, RTL.</b> Düzen tamamen aynalanıyor; içerideki Latin ve Kiril metinler kendi yönünü koruyor.</sub></td>
<td><img src="docs/screenshots/06-profile.jpg" alt="Profil" /><br /><sub><b>Profil ve değerlendirmeler.</b> Puan, sürücü ve yolcu olarak yolculuk sayısı.</sub></td>
</tr>
<tr>
<td><img src="docs/screenshots/03-publish.jpg" alt="İlan verme" /><br /><sub><b>İlan çözümleme.</b> Serbest metin → yapılandırılmış yolculuk; her alan düzeltilebilir.</sub></td>
<td align="center"><img src="docs/screenshots/07-mobile.jpg" width="300" alt="Mobil görünüm" /><br /><sub><b>Telefon.</b> Hedef kitle buradan giriyor.</sub></td>
</tr>
<tr>
<td><img src="docs/screenshots/11-admin.jpg" alt="Yönetim paneli" /><br /><sub><b>Yönetim paneli.</b> Kullanıcılar, şikayetler, yasaklar, güzergâhlar ve işlem kaydı.</sub></td>
<td><img src="docs/screenshots/09-sos.jpg" alt="SOS butonu" /><br /><sub><b>SOS.</b> Acil servisler, kampüs güvenliği ve kişisel acil durum kişileri tek pencerede.</sub></td>
</tr>
<tr>
<td><img src="docs/screenshots/12-admin-roles.jpg" alt="Roller ve yetkiler" /><br /><sub><b>Roller ve yetkiler.</b> İki kurucu, en fazla beş yönetici, yetkiler tek tek veriliyor.</sub></td>
<td><img src="docs/screenshots/10-ride-rtl.jpg" alt="Kadın yolculuğu, Arapça" /><br /><sub><b>Kadın yolculuğu, Arapça arayüz.</b> Telefon ve buluşma noktası onaya kadar gizli.</sub></td>
</tr>
</table>

---

## 🤖 Yapay zekâ modelini bağlama

**Uygulama anahtarsız da tam çalışır.** Anahtar yoksa yerleşik ilan çözümleyici ve ifade sözlüğü
devreye girer — demo ne anahtarsız ne internetsiz bozulur.

Gerçek modeli bağlamak için:

1. Ücretsiz anahtar al:
   * **Groq** — <https://console.groq.com/keys> (llama-3.3-70b, cömert ücretsiz kota)
   * **Google Gemini** — <https://aistudio.google.com/apikey> (gemini-2.0-flash)
2. Uygulamada: **Ayarlar → Yapay zekâ modeli** → sağlayıcıyı seç, anahtarı yapıştır
3. **Anahtarı test et** — yeşil onay görünürse hazır

> Anahtar yalnızca tarayıcının `localStorage`'ında durur ve seçtiğin sağlayıcı dışında
> hiçbir yere gitmez. Depoda anahtar yok, olmamalı da.

<img src="docs/screenshots/08-settings.jpg" width="620" alt="Yapay zekâ ayarları" />

---

## 🏗 Mimari

Uygulama framework'süz ve build adımı olmadan saf JavaScript ile yazıldı — böylece takımdaki
herkes yarım dakikada çalıştırıp yayına alabiliyor ve sunumda çökecek bir şey kalmıyor.

```
index.html                 tek giriş noktası
styles/
  tokens.css               tasarım sistemi: palet, tipografi, spacing, gölge, animasyon
  base.css                 reset + tipografi
  components.css           buton, input, kart, rozet, sohbet balonu, harita, modal
  views.css                sayfa düzenleri, responsive, RTL
src/
  util.js                  DOM yardımcıları, tarih/coğrafya, ikon seti
  i18n.js                  8 dilli çeviri motoru, RTL yönetimi
  locales/*.js             çeviri dosyaları — her biri 266 anahtar, tam eşleşmeli
  places.js                Yekaterinburg durakları: koordinat + parser için takma adlar
  legal.js                 hukuki metinler (ru/en)
  store.js                 VERİ KATMANI (soyut) — şu an localStorage adaptörü
                           roller, yetkiler, yasaklar, şikayetler, bildirimler, güven
  seed.js                  demo veri: kullanıcı, ilan, sohbet, puan, moderasyon
  ai.js                    Groq/Gemini istemcisi + çevrimdışı parser + ifade sözlüğü
  matching.js              eşleşme skoru + şablon açıklamalar
  map.js                   OSM karo haritası: projeksiyon, sürükleme, zum, fallback
  ui.js                    UI kit: toast, modal, avatar, yıldız, halka, form alanları
  shell.js                 şapka, navigasyon, router
  views/*.js               ekranlar (admin, notifications, legal dahil)
  main.js                  başlatma, service worker kaydı, hatırlatmalar
manifest.webmanifest       PWA manifesti
sw.js                      service worker: çevrimdışı önbellek
scripts/check-locales.js   çeviri anahtarı denetimi (CI'da çalışır)
```

### Eşleştirme algoritması

```
skor = 0.45 · güzergâh yakınlığı
     + 0.32 · saat farkı (esneklik penceresi ±5…90 dakika)
     + 0.23 · sürücüye duyulan güven
```

Güven; tamamlanan yolculuk sayısı, ortalama puan ve araç/ehliyet bilgilerinin
doluluğundan oluşuyor. Yasaklı sürücüler sıfır alıp aramadan düşüyor, böylece
doğrulanmış sürücüler kendiliğinden yukarı çıkıyor.

Güzergâh yakınlığı, kalkış ve varış noktaları için ayrı ayrı haversine formülüyle hesaplanıyor.
«Bu yolculuk neden» açıklaması **modelle değil şablonla** üretiliyor: anında görünmeli,
sıfır maliyetli olmalı ve asla uydurmamalı.

### Gerçek veritabanına geçiş

Tüm veri erişimi [`src/store.js`](src/store.js) içindeki `adapter` nesnesinden geçiyor
(`load` / `save` artı `all` / `find` / `where` / `insert` / `update` / `remove`).
Supabase veya Firebase'e geçmek için sadece bu nesneyi değiştirmek yeterli — ekranlar değişmiyor.

---

## 🎬 Sunum senaryosu (5 dakika)

1. **Ana sayfa** — dili Rusça'dan Arapça'ya çevir: arayüz anında RTL'e dönüyor.
2. **İlan ver** — şunu yaz: *«Завтра еду с Уралмаша в кампус в 8:30, могу взять двоих, 150 рублей»*
   → «Разобрать с ИИ» → hazır ilan ve haritada güzergâh.
3. **Yolculuk bul** — «Bu yolculuk neden»i aç: saat farkı, güzergâh örtüşmesi, sürücü puanı.
4. **Sohbetler** — Hasan (Türkçe) ↔ Мария (Rusça) yazışması; her mesajda orijinal + çeviri.
   Kullanıcı menüsünden **kullanıcı değiştir** — aynı diyalog karşı taraftan.
5. **Yolculuklarım → Tamamlanan** — puan ver, profilde puanın güncellendiğini göster.
6. **SOS** — sabit buton: acil servisler, kampüs güvenliği ve kişisel acil durum kişileri.
7. **Yönetim paneli** — kurucu olarak gir (`yldzhasan29@gmail.com`), şikayeti göster,
   yasak ver, sınırlı yetkiyle yönetici ata ve işlem kaydını aç.

---

## 🚧 MVP kapsamı dışında

Dinamik fiyatlandırma ve talep tahmini orijinal kеys tanımında var ama bu sürümde bilinçli olarak
kapsam dışı bırakıldı.

Basitleştirilen ve arayüzde bu şekilde belirtilen noktalar:

* UrFU IdM/SSO entegrasyonu yerine `@stud.urfu.ru` format kontrolü;
* ehliyet, plaka ve araç bilgisini sürücünün kendisi giriyor, resmî doğrulama yok —
  «doğrulanmış sürücü» rozeti yalnızca alanların dolu olduğunu gösteriyor;
* SOS butonu acil servis ve yakın kişilerin numaralarını gösteriyor, otomatik arama yapmıyor.

---

## 🤝 Takım

Hata bildirimi, arayüz ve çeviri önerileri için: [CONTRIBUTING.md](CONTRIBUTING.md).

## Lisans

[MIT](LICENSE)
