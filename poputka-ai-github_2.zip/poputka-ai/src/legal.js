/* ==========================================================
   Правовые документы. Написаны для студенческого сервиса и
   намеренно короткие: их должно быть реально прочитать.
   Язык — русский и английский; интерфейс подставляет
   английский для остальных локалей.
   ========================================================== */
(function (PP) {
  'use strict';
  var UPDATED = '2026-09-07';

  var DOCS = {
    privacy: {
      ru: {
        title: 'Политика конфиденциальности',
        body: [
          ['Что мы храним',
           'Имя, университетскую почту, язык общения, а также данные, которые вы вводите сами: телефон, сведения об автомобиле и правах, экстренные контакты, тексты объявлений и сообщений, оценки и отзывы.'],
          ['Где это хранится',
           'В текущей версии сервиса все данные хранятся локально в вашем браузере и не покидают устройство. Мы не ведём серверную базу пользователей.'],
          ['Что видят другие',
           'Имя, язык, рейтинг, отзывы и опубликованные поездки видны всем. Телефон и точная точка встречи открываются только после того, как водитель подтвердил бронь.'],
          ['Пол',
           'Пол используется исключительно для поездок с пометкой «только для женщин» и никогда не показывается в профиле.'],
          ['Внешние сервисы',
           'Если вы подключили модель ИИ, тексты объявлений и сообщений отправляются выбранному провайдеру (Groq или Google) для разбора и перевода. Ключ хранится только в вашем браузере. Карта загружает изображения с серверов OpenStreetMap.'],
          ['Удаление данных',
           'Кнопка сброса в настройках стирает все локальные данные. Выход из аккаунта полностью завершает сессию на устройстве.']
        ]
      },
      en: {
        title: 'Privacy policy',
        body: [
          ['What we store',
           'Your name, university email, chat language, and whatever you enter yourself: phone number, car and licence details, emergency contacts, listing and message texts, ratings and reviews.'],
          ['Where it is stored',
           'In the current version all data is stored locally in your browser and never leaves your device. We run no server-side user database.'],
          ['What others see',
           'Name, language, rating, reviews and published rides are public. Phone number and the exact meeting point are revealed only after the driver confirms your booking.'],
          ['Gender',
           'Gender is used solely for rides marked women-only and is never displayed on your profile.'],
          ['Third-party services',
           'If you connect an AI model, listing and message texts are sent to the provider you chose (Groq or Google) for parsing and translation. The key stays in your browser. The map loads tiles from OpenStreetMap servers.'],
          ['Deleting your data',
           'The reset button in Settings wipes all local data. Signing out ends the session on the device completely.']
        ]
      }
    },

    terms: {
      ru: {
        title: 'Условия использования',
        body: [
          ['Кто может пользоваться',
           'Сервис предназначен для студентов и сотрудников УрФУ. Регистрация возможна с адресом в домене @stud.urfu.ru.'],
          ['Что это за сервис',
           '«Попутка ИИ» — доска объявлений для совместных поездок. Мы не перевозчик, не таксопарк и не посредник в расчётах. Договорённость о поездке — прямое соглашение между водителем и пассажиром.'],
          ['Деньги',
           'Сервис не берёт комиссию и не проводит платежи. Указанная в объявлении сумма — добровольный вклад в расходы на топливо, а не плата за перевозку.'],
          ['Достоверность данных',
           'Сведения о водителе, автомобиле и правах указываются самим пользователем и не проверяются официально. Значок «проверенный водитель» означает лишь то, что поля заполнены.'],
          ['Что запрещено',
           'Коммерческие перевозки, реклама, сбор данных других пользователей, публикация чужих контактов, оскорбления и любые действия, создающие опасность для попутчиков.'],
          ['Санкции',
           'Нарушения приводят к предупреждению, временной или постоянной блокировке. Решение можно оспорить через форму апелляции.']
        ]
      },
      en: {
        title: 'Terms of use',
        body: [
          ['Who can use it',
           'The service is intended for UrFU students and staff. Registration requires an @stud.urfu.ru address.'],
          ['What this service is',
           'Poputka AI is a noticeboard for shared rides. We are not a carrier, not a taxi company and not a payment intermediary. A ride agreement is made directly between driver and passenger.'],
          ['Money',
           'The service takes no commission and processes no payments. The amount in a listing is a voluntary contribution to fuel costs, not a fare.'],
          ['Accuracy of details',
           'Driver, car and licence details are self-declared and are not officially verified. The "verified driver" badge only means the fields are filled in.'],
          ['What is not allowed',
           'Commercial transport, advertising, harvesting other users’ data, publishing someone else’s contacts, insults, and anything that puts fellow passengers at risk.'],
          ['Enforcement',
           'Violations lead to a warning, a temporary ban or a permanent ban. Any decision can be challenged through the appeal form.']
        ]
      }
    },

    liability: {
      ru: {
        title: 'Ограничение ответственности',
        body: [
          ['Мы не участвуем в поездке',
           'Сервис только сводит людей, которым по пути. Мы не контролируем поездку, не проверяем техническое состояние автомобиля и не несём ответственности за то, что происходит в пути.'],
          ['Ответственность сторон',
           'Водитель отвечает за соблюдение правил дорожного движения, наличие прав, страховки и исправность автомобиля. Пассажир отвечает за собственную безопасность и за свои вещи.'],
          ['Проверки',
           'Мы не проводим проверку документов, судимостей или водительского стажа. Оценивайте попутчика по рейтингу, отзывам и переписке.'],
          ['Форс-мажор',
           'Мы не гарантируем, что поездка состоится, что водитель приедет вовремя или что данные в объявлении точны.'],
          ['Экстренные ситуации',
           'Кнопка SOS показывает контакты служб и ваших близких, но не вызывает их автоматически. В опасной ситуации звоните по номеру 112.']
        ]
      },
      en: {
        title: 'Limitation of liability',
        body: [
          ['We are not part of the ride',
           'The service only introduces people going the same way. We do not supervise rides, do not inspect vehicles and are not responsible for what happens on the road.'],
          ['Who is responsible',
           'The driver is responsible for traffic rules, a valid licence, insurance and a roadworthy car. The passenger is responsible for their own safety and belongings.'],
          ['No background checks',
           'We do not verify documents, criminal records or driving experience. Judge your companion by ratings, reviews and the conversation.'],
          ['No guarantees',
           'We do not guarantee that a ride will take place, that the driver will be on time, or that the listing details are accurate.'],
          ['Emergencies',
           'The SOS button shows the contacts of emergency services and your own people, but does not call them automatically. In danger, dial 112.']
        ]
      }
    },

    rules: {
      ru: {
        title: 'Правила сообщества',
        body: [
          ['Приезжайте вовремя',
           'Опоздание на десять минут ломает чужое утро. Не можете — предупредите в чате заранее.'],
          ['Пишите как человеку',
           'Автоперевод передаёт смысл, но не сглаживает грубость. Уважение обязательно на любом языке.'],
          ['Договаривайтесь заранее',
           'Точка встречи, багаж, музыка, окно, курение — обсудите до поездки, а не в машине.'],
          ['Честный рейтинг',
           'Ставьте оценку по факту поездки. Месть за отказ подвезти или за отклонённую бронь — повод для жалобы на вас.'],
          ['Безопасность важнее вежливости',
           'Если за рулём опасно, вы вправе прервать поездку. Расскажите об этом через жалобу — это защитит следующего.'],
          ['Никакого бизнеса',
           'Совместная поездка — это разделённые расходы. Регулярная перевозка за деньги — уже другая история и другой сервис.']
        ]
      },
      en: {
        title: 'Community rules',
        body: [
          ['Be on time',
           'Ten minutes late ruins someone else’s morning. If you cannot make it, say so in the chat in advance.'],
          ['Write like you would speak',
           'Auto-translation conveys meaning but does not soften rudeness. Respect is required in every language.'],
          ['Agree in advance',
           'Meeting point, luggage, music, window, smoking — settle it before the ride, not in the car.'],
          ['Rate honestly',
           'Rate the ride that actually happened. Revenge for a declined booking is itself a reason to be reported.'],
          ['Safety over politeness',
           'If the driving is unsafe, you may end the ride. Report it — that protects the next passenger.'],
          ['No business',
           'A shared ride means shared costs. Regular paid transport is a different story and a different service.']
        ]
      }
    }
  };

  PP.legal = {
    UPDATED: UPDATED,
    ORDER: ['privacy', 'terms', 'liability', 'rules'],
    get: function (doc, lang) {
      var d = DOCS[doc] || DOCS.privacy;
      return d[lang === 'ru' ? 'ru' : 'en'];
    }
  };
})(window.PP);
