/* ============ Панель управления (основатели и админы) ============ */
(function (PP) {
  'use strict';
  window.PP.views = window.PP.views || {};
  var U = PP.util, h = U.h, icon = U.icon, ui = PP.ui, S = PP.store;

  PP.views.admin = function (root, params) {
    var t = PP.i18n.t, lang = PP.i18n.get();
    var me = S.currentUser();

    if (!me || !S.isStaff(me)) {
      root.appendChild(h('div', { class: 'wrap section' },
        h('div', { class: 'card card--pad' },
          ui.empty('shield', t('adm_no_access'), '',
            h('a', { class: 'btn btn--soft', href: '#/', text: t('nav_home') })))));
      return;
    }

    var founder = S.isFounder(me);
    var tabs = [];
    if (S.can(me, 'users')) tabs.push('users');
    if (S.can(me, 'reports')) tabs.push('reports');
    if (S.can(me, 'bans')) tabs.push('bans');
    if (founder) tabs.push('admins');
    tabs.push('routes');
    if (founder) tabs.push('logs');
    var tab = tabs.indexOf(params.query.tab) >= 0 ? params.query.tab : tabs[0];

    var body = h('div', { class: 'stack gap-4' });
    var tabBar = h('div', { class: 'tabs' }, tabs.map(function (id) {
      return h('button', {
        class: id === tab ? 'is-active' : '', text: t('adm_tab_' + id),
        onclick: function () {
          tab = id;
          Array.prototype.forEach.call(tabBar.children, function (c, i) {
            c.className = tabs[i] === id ? 'is-active' : '';
          });
          paint();
        }
      });
    }));

    root.appendChild(h('div', { class: 'wrap section stack gap-6' }, [
      h('div', { class: 'stack gap-3 reveal' }, [
        h('div', { class: 'row gap-2 center wrapflex' }, [
          ui.badge(t(founder ? 'adm_founder' : 'adm_admin'), founder ? 'ember' : 'brand', 'shield'),
          h('span', { class: 'muted t-sm', text: me.email })
        ]),
        h('h1', { text: t('adm_title') })
      ]),
      statsRow(),
      tabBar,
      body
    ]));

    /* ---------- статистика ---------- */
    function statsRow() {
      var completed = S.where('rides', function (r) { return r.status === 'completed'; }).length;
      var openReports = S.where('reports', function (r) { return r.status === 'new'; }).length;
      var activeBans = S.all('users').filter(function (u) { return !!S.activeBan(u.id); }).length;
      var cards = [
        ['users', S.all('users').length, 'adm_stat_users'],
        ['car', S.all('rides').length, 'adm_stat_rides'],
        ['checkCircle', completed, 'adm_stat_trips'],
        ['info', openReports, 'adm_stat_reports'],
        ['shield', activeBans, 'adm_stat_bans']
      ];
      return h('div', { class: 'admstats reveal d1' }, cards.map(function (c) {
        return h('div', { class: 'admstat' }, [
          h('span', { class: 'admstat__ic', html: icon(c[0], 18) }),
          h('strong', { class: 'admstat__v tabular', text: String(c[1]) }),
          h('span', { class: 'admstat__l', text: t(c[2]) })
        ]);
      }));
    }

    /* ---------- вкладки ---------- */
    function paint() {
      U.clear(body);
      if (tab === 'users') return usersTab();
      if (tab === 'reports') return reportsTab();
      if (tab === 'bans') return bansTab();
      if (tab === 'admins') return adminsTab();
      if (tab === 'routes') return routesTab();
      if (tab === 'logs') return logsTab();
    }

    function userRow(u, extra) {
      var st = S.userStats(u.id);
      var ban = S.activeBan(u.id);
      return h('div', { class: 'admrow' }, [
        ui.avatar(u, 'sm'),
        h('div', { class: 'stack gap-1 grow', style: { minWidth: 0 } }, [
          h('div', { class: 'row gap-2 center wrapflex' }, [
            h('a', { class: 'strong t-sm', href: '#/profile/' + u.id, text: u.name }),
            ui.roleBadge(u),
            ban ? ui.badge(t(ban.level === 'temp' ? 'adm_ban_temp' : 'adm_ban_perm'), 'danger', 'shield') : null
          ]),
          h('span', { class: 'muted t-xs truncate', text: u.email }),
          h('span', { class: 'row gap-2 center muted t-2xs wrapflex' }, [
            h('span', { text: t('p_trips') + ': ' + st.trips }),
            st.count ? h('span', { class: 'row gap-1 center' }, [ui.stars(st.avg), h('span', { text: String(st.avg) })]) : null,
            ui.badge(t('tr_' + S.trustOf(u.id).level), 'outline')
          ])
        ]),
        extra || null
      ]);
    }

    function usersTab() {
      var q = h('input', { class: 'input', placeholder: t('c_search') });
      var list = h('div', { class: 'stack gap-3' });
      function fill() {
        U.clear(list);
        var term = q.value.trim().toLowerCase();
        S.all('users').filter(function (u) {
          return !term || (u.name + ' ' + u.email).toLowerCase().indexOf(term) >= 0;
        }).forEach(function (u) {
          var actions = h('div', { class: 'row gap-2 wrapflex' });
          if (S.can(me, 'bans') && !S.isFounder(u) && u.id !== me.id) {
            actions.appendChild(h('button', {
              class: 'btn btn--xs btn--danger', text: t('adm_warn') + ' / ' + t('adm_ban_temp'),
              onclick: function () { banModal(u); }
            }));
          }
          list.appendChild(userRow(u, actions));
        });
      }
      q.addEventListener('input', U.debounce(fill, 150));
      body.appendChild(h('div', { class: 'card card--pad stack gap-4' }, [q, list]));
      fill();
    }

    function reportsTab() {
      var list = S.all('reports').sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
      var box = h('div', { class: 'stack gap-3' });
      if (!list.length) box.appendChild(h('p', { class: 'dim t-sm', text: t('adm_empty_reports') }));
      list.forEach(function (r) {
        var from = S.find('users', r.fromUserId), target = S.find('users', r.targetUserId);
        box.appendChild(h('div', { class: 'admcard' }, [
          h('div', { class: 'row gap-2 center wrapflex' }, [
            ui.badge(t('rep_r_' + r.reason), 'ember', 'info'),
            ui.badge(t(r.status === 'new' ? 'rep_status_new' : 'rep_status_done'),
                     r.status === 'new' ? 'danger' : 'mint'),
            h('span', { class: 'grow' }),
            h('span', { class: 'muted t-2xs', text: PP.i18n.dateLabel(r.createdAt) })
          ]),
          h('div', { class: 'row gap-3 center wrapflex', style: { marginTop: '10px' } }, [
            h('span', { class: 'muted t-xs', text: t('adm_by') + ':' }),
            h('a', { class: 't-sm strong', href: '#/profile/' + (from ? from.id : ''), text: from ? from.name : '—' }),
            h('span', { html: icon('arrowRight', 14), style: { display: 'flex', color: 'var(--ink-300)' } }),
            h('a', { class: 't-sm strong', href: '#/profile/' + (target ? target.id : ''), text: target ? target.name : '—' })
          ]),
          r.text ? h('p', { class: 'dim t-sm', style: { marginTop: '10px' }, text: r.text, dir: 'auto' }) : null,
          h('div', { class: 'row gap-2 wrapflex', style: { marginTop: '12px' } }, [
            r.status === 'new' ? h('button', {
              class: 'btn btn--xs btn--soft', text: t('rep_reviewed'),
              onclick: function () { S.reviewReport(r.id, me.id, false); ui.toast(t('rep_reviewed'), 'ok'); paint(); }
            }) : null,
            r.status === 'new' ? h('button', {
              class: 'btn btn--xs btn--ghost', text: t('rep_dismiss'),
              onclick: function () { S.reviewReport(r.id, me.id, true); paint(); }
            }) : null,
            (S.can(me, 'bans') && target) ? h('button', {
              class: 'btn btn--xs btn--danger', text: t('adm_ban_temp'),
              onclick: function () { banModal(target); }
            }) : null
          ])
        ]));
      });
      body.appendChild(h('div', { class: 'card card--pad' }, box));
    }

    function bansTab() {
      var list = S.all('bans').sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
      var box = h('div', { class: 'stack gap-3' });
      if (!list.length) box.appendChild(h('p', { class: 'dim t-sm', text: t('adm_empty_bans') }));
      list.forEach(function (b) {
        var u = S.find('users', b.userId), by = S.find('users', b.byAdminId);
        var levelKey = b.level === 'warning' ? 'adm_warn' : b.level === 'temp' ? 'adm_ban_temp' : 'adm_ban_perm';
        box.appendChild(h('div', { class: 'admcard' }, [
          h('div', { class: 'row gap-2 center wrapflex' }, [
            ui.badge(t(levelKey), b.level === 'warning' ? 'ember' : 'danger', 'shield'),
            b.lifted ? ui.badge(t('adm_unban'), 'mint', 'checkCircle') : null,
            h('span', { class: 'grow' }),
            h('span', { class: 'muted t-2xs', text: PP.i18n.dateLabel(b.createdAt) })
          ]),
          h('div', { class: 'row gap-3 center wrapflex', style: { marginTop: '10px' } }, [
            ui.avatar(u, 'xs'),
            h('a', { class: 't-sm strong', href: '#/profile/' + (u ? u.id : ''), text: u ? u.name : '—' }),
            h('span', { class: 'muted t-xs', text: t('adm_by') + ': ' + (by ? by.name : '—') }),
            b.until ? h('span', { class: 'muted t-xs', text: t('adm_until') + ': ' + PP.i18n.dateLabel(b.until) }) : null
          ]),
          h('p', { class: 'dim t-sm', style: { marginTop: '8px' },
                   text: t('adm_reason') + ': ' + (b.reason || '—'), dir: 'auto' }),
          b.appeal ? h('div', { class: 'note', style: { marginTop: '10px' } }, [
            h('span', { html: icon('info', 16), style: { display: 'flex', flex: 'none' } }),
            h('div', { class: 'stack gap-1' }, [
              h('strong', { class: 't-sm', text: t('adm_appeal') + ' · ' + b.appeal.status }),
              h('span', { class: 't-sm', text: b.appeal.text || '—', dir: 'auto' })
            ])
          ]) : null,
          h('div', { class: 'row gap-2 wrapflex', style: { marginTop: '12px' } }, [
            (!b.lifted && S.can(me, 'bans')) ? h('button', {
              class: 'btn btn--xs btn--soft', text: t('adm_unban'),
              onclick: function () { S.liftBan(b.id, me.id); ui.toast(t('adm_unban'), 'ok'); paint(); }
            }) : null,
            (b.appeal && b.appeal.status === 'new' && S.can(me, 'bans')) ? h('button', {
              class: 'btn btn--xs btn--soft', text: t('adm_appeal_accept'),
              onclick: function () { S.resolveAppeal(b.id, true, me.id); paint(); }
            }) : null,
            (b.appeal && b.appeal.status === 'new' && S.can(me, 'bans')) ? h('button', {
              class: 'btn btn--xs btn--ghost', text: t('adm_appeal_reject'),
              onclick: function () { S.resolveAppeal(b.id, false, me.id); paint(); }
            }) : null
          ])
        ]));
      });
      body.appendChild(h('div', { class: 'card card--pad' }, box));
    }

    function adminsTab() {
      var admins = S.admins();
      var box = h('div', { class: 'stack gap-4' });

      box.appendChild(h('div', { class: 'row gap-2 center wrapflex' }, [
        h('strong', { text: t('adm_tab_admins') }),
        ui.badge(admins.length + ' / ' + S.MAX_ADMINS, admins.length >= S.MAX_ADMINS ? 'danger' : 'outline')
      ]));

      S.founders().forEach(function (f) {
        box.appendChild(userRow(f, ui.badge(t('adm_founder'), 'ember', 'shield')));
      });

      admins.forEach(function (a) {
        var perms = a.perms || {};
        var row = h('div', { class: 'stack gap-3' }, [
          userRow(a, h('button', {
            class: 'btn btn--xs btn--danger', text: t('adm_remove_admin'),
            onclick: function () { S.removeAdmin(a.id, me.id); ui.toast(t('adm_remove_admin'), 'info'); paint(); }
          })),
          h('div', { class: 'permrow' }, ['users', 'reports', 'bans'].map(function (k) {
            var input = h('input', { type: 'checkbox', checked: perms[k] ? true : null });
            input.addEventListener('change', function () {
              var next = Object.assign({}, a.perms || {});
              next[k] = this.checked;
              S.setPerms(a.id, next, me.id);
              ui.toast(t('tst_saved'), 'ok');
            });
            return h('label', { class: 'switch' }, [
              input, h('span', { class: 'switch__track' }),
              h('span', { class: 't-xs strong', text: t('adm_p_' + k) })
            ]);
          }).concat([
            h('span', { class: 'muted t-2xs', text: t('adm_logs_only') })
          ]))
        ]);
        box.appendChild(h('div', { class: 'admcard' }, row));
      });

      var candidates = S.all('users').filter(function (u) {
        return S.roleOf(u) === 'user' && !S.activeBan(u.id);
      });
      box.appendChild(h('div', { class: 'divider' }));
      box.appendChild(h('strong', { text: t('adm_make_admin') }));
      if (admins.length >= S.MAX_ADMINS) {
        box.appendChild(h('p', { class: 'field__error', text: t('adm_limit') }));
      } else {
        box.appendChild(h('div', { class: 'row gap-2 wrapflex' }, candidates.slice(0, 12).map(function (u) {
          return h('button', {
            class: 'chip',
            onclick: function () {
              var res = S.makeAdmin(u.id, { users: true, reports: true, bans: false }, me.id);
              if (!res.ok) { ui.toast(t('adm_limit'), 'err'); return; }
              ui.toast(t('adm_make_admin'), 'ok'); paint();
            }
          }, [ui.avatar(u, 'xs'), h('span', { text: u.name })]);
        })));
      }
      body.appendChild(h('div', { class: 'card card--pad' }, box));
    }

    function routesTab() {
      var agg = {};
      S.all('rides').forEach(function (r) {
        var key = r.fromId + '>' + r.toId;
        if (!agg[key]) agg[key] = { fromId: r.fromId, toId: r.toId, total: 0, done: 0, seats: 0 };
        agg[key].total++;
        agg[key].seats += r.seats || 0;
        if (r.status === 'completed') agg[key].done++;
      });
      var rows = Object.keys(agg).map(function (k) { return agg[k]; })
        .sort(function (a, b) { return b.total - a.total; });
      var box = h('div', { class: 'stack gap-3' });
      rows.forEach(function (r) {
        box.appendChild(h('div', { class: 'admrow' }, [
          h('span', { class: 'route__dot route__dot--a' }),
          h('div', { class: 'stack gap-0 grow', style: { minWidth: 0 } }, [
            h('strong', { class: 't-sm', text: PP.places.labelById(r.fromId, lang) + ' → ' + PP.places.labelById(r.toId, lang) }),
            h('span', { class: 'muted t-xs', text: t('adm_stat_rides') + ': ' + r.total + ' · ' + t('adm_stat_trips') + ': ' + r.done })
          ]),
          ui.badge(String(r.total), 'outline', 'car')
        ]));
      });
      body.appendChild(h('div', { class: 'card card--pad' }, box));
    }

    function logsTab() {
      var list = S.logs();
      var box = h('div', { class: 'stack gap-2' });
      box.appendChild(h('div', { class: 'note' }, [
        h('span', { html: icon('shield', 16), style: { display: 'flex', flex: 'none' } }),
        h('span', { class: 't-sm', text: t('adm_logs_only') })
      ]));
      if (!list.length) box.appendChild(h('p', { class: 'dim t-sm', text: t('adm_empty_logs') }));
      list.forEach(function (l) {
        var admin = S.find('users', l.adminId), target = S.find('users', l.targetId);
        box.appendChild(h('div', { class: 'logrow' }, [
          h('span', { class: 'logrow__act', text: l.action }),
          h('span', { class: 't-sm grow truncate', text: (admin ? admin.name : '—') + ' → ' + (target ? target.name : l.targetId) }),
          h('span', { class: 'muted t-2xs nowrap', text: PP.i18n.dateLabel(l.createdAt) + ' ' + U.hhmm(l.createdAt) })
        ]));
      });
      body.appendChild(h('div', { class: 'card card--pad' }, box));
    }

    /* ---------- модалка блокировки ---------- */
    function banModal(user) {
      var level = 'warning', days = 7;
      ui.modal({
        render: function (box, close) {
          var levelSel = ui.select([
            { value: 'warning', label: t('adm_warn') },
            { value: 'temp', label: t('adm_ban_temp') },
            { value: 'permanent', label: t('adm_ban_perm') }
          ], level, function (v) { level = v; daysField.classList.toggle('hide', v !== 'temp'); });
          var daysIn = h('input', { class: 'input', type: 'number', min: '1', max: '365', value: '7' });
          daysIn.addEventListener('input', function () { days = parseInt(daysIn.value, 10) || 7; });
          var daysField = ui.field(t('adm_days'), daysIn);
          daysField.classList.add('hide');
          var reason = h('textarea', { class: 'textarea', rows: 3, placeholder: t('adm_reason_ph') });
          box.appendChild(h('div', { class: 'stack gap-5' }, [
            h('div', { class: 'stack gap-2' }, [
              h('h3', { text: t('adm_tab_bans') }),
              h('div', { class: 'row gap-3 center' }, [ui.avatar(user, 'sm'), h('strong', { text: user.name })])
            ]),
            ui.field(t('adm_role'), levelSel),
            daysField,
            ui.field(t('adm_reason'), reason),
            h('div', { class: 'row gap-3', style: { justifyContent: 'flex-end' } }, [
              h('button', { class: 'btn btn--ghost', text: t('c_cancel'), onclick: close }),
              h('button', {
                class: 'btn btn--danger', text: t('c_confirm'),
                onclick: function () {
                  S.banUser(user.id, level, reason.value.trim(), days, me.id);
                  close(); ui.toast(t('adm_tab_bans'), 'ok'); paint();
                }
              })
            ])
          ]));
        }
      });
    }

    paint();
  };
})(window.PP);
