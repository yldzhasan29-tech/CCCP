/* ============ Правовые документы ============ */
(function (PP) {
  'use strict';
  window.PP.views = window.PP.views || {};
  var U = PP.util, h = U.h, icon = U.icon, ui = PP.ui;

  PP.views.legal = function (root, params) {
    var t = PP.i18n.t;
    var lang = PP.i18n.get();
    var docKey = PP.legal.ORDER.indexOf(params.doc) >= 0 ? params.doc : 'privacy';
    var doc = PP.legal.get(docKey, lang);

    var nav = h('aside', { class: 'card card--pad-sm stack gap-1 legalnav' },
      PP.legal.ORDER.map(function (k) {
        return h('a', {
          class: 'legalnav__item' + (k === docKey ? ' is-active' : ''),
          href: '#/legal/' + k, text: t('lg_' + k)
        });
      }));

    var article = h('article', { class: 'card card--pad stack gap-5 legaldoc' }, [
      h('div', { class: 'stack gap-2' }, [
        h('div', { class: 'row gap-2 center wrapflex' }, [
          ui.badge(t('lg_updated') + ' ' + PP.legal.UPDATED, 'outline', 'calendar'),
          lang !== 'ru' && lang !== 'en' ? ui.badge(t('lg_lang_note'), 'brand', 'globe') : null
        ]),
        h('h1', { text: doc.title })
      ]),
      h('div', { class: 'stack gap-5' }, doc.body.map(function (sec) {
        return h('section', { class: 'stack gap-2' }, [
          h('h3', { text: sec[0] }),
          h('p', { class: 'dim', text: sec[1] })
        ]);
      })),
      h('div', { class: 'note' }, [
        h('span', { html: icon('info', 16), style: { display: 'flex', flex: 'none' } }),
        h('span', { class: 't-sm', text: t('v_selfdecl') })
      ])
    ]);

    root.appendChild(h('div', { class: 'wrap section stack gap-5' }, [
      h('h2', { text: t('lg_title') }),
      h('div', { class: 'legallayout' }, [nav, article])
    ]));
  };
})(window.PP);
