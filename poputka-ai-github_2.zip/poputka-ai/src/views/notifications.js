/* ============ Центр уведомлений ============ */
(function (PP) {
  'use strict';
  window.PP.views = window.PP.views || {};
  var U = PP.util, h = U.h, icon = U.icon, ui = PP.ui, S = PP.store;

  var ICONS = {
    new_req: 'users', accepted: 'checkCircle', declined: 'x', cancelled: 'x',
    ride_off: 'x', soon: 'clock', delayed: 'clock', status: 'car', ban: 'shield'
  };

  PP.views.notifications = function (root) {
    var t = PP.i18n.t;
    var me = S.currentUser();
    if (!me) {
      root.appendChild(h('div', { class: 'wrap section' },
        h('div', { class: 'card card--pad' },
          ui.empty('info', t('n_empty'), t('r_login'),
            h('a', { class: 'btn btn--primary', href: '#/auth', text: t('nav_login') })))));
      return;
    }
    var list = S.notificationsFor(me.id);

    var body = list.length
      ? h('div', { class: 'stack gap-3' }, list.map(function (n, i) {
          return h('div', { class: 'notifcard' + (n.read ? '' : ' is-new') + ' reveal' + (i < 6 ? ' d' + (i + 1) : '') }, [
            h('span', { class: 'notifcard__ic', html: icon(ICONS[n.type] || 'info', 17) }),
            h('div', { class: 'stack gap-1 grow', style: { minWidth: 0 } }, [
              h('span', { class: 't-sm strong', text: PP.shell.notifText(n) }),
              h('span', { class: 'muted t-xs', text: PP.i18n.dayLabel(n.createdAt) + ' · ' + U.hhmm(n.createdAt) })
            ]),
            n.read ? null : h('span', { class: 'unread-dot' })
          ]);
        }))
      : h('div', { class: 'card card--pad' }, ui.empty('info', t('n_empty'), t('n_empty_hint')));

    root.appendChild(h('div', { class: 'wrap wrap--narrow section stack gap-5' }, [
      h('div', { class: 'row between center wrapflex gap-3' }, [
        h('h1', { text: t('n_title') }),
        list.length ? h('button', {
          class: 'btn btn--soft btn--sm', text: t('n_mark_all'),
          onclick: function () { S.markNotificationsRead(me.id); PP.shell.render(); }
        }) : null
      ]),
      body
    ]));
  };
})(window.PP);
