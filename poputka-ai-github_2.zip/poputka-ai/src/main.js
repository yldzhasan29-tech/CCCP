/* ============ Точка входа ============ */
(function (PP) {
  'use strict';

  function boot() {
    PP.i18n.set(PP.i18n.detect(), true);
    PP.seed.ensure();

    PP.i18n.onChange(function () { PP.shell.render(); });
    window.addEventListener('hashchange', function () { PP.shell.render(); });

    PP.shell.render();
    registerServiceWorker();
    scheduleDepartureReminders();

    /* глобальный перехват ошибок — чтобы демонстрация не «падала» молча */
    window.addEventListener('error', function (e) {
      console.error('[Попутка ИИ]', e.message);
    });
  }

  /* ---------- PWA ---------- */
  function registerServiceWorker() {
    if (!('serviceWorker' in navigator)) return;
    if (location.protocol !== 'https:' && location.hostname !== 'localhost' &&
        location.hostname !== '127.0.0.1') return;   /* с file:// SW не работает */
    try {
      navigator.serviceWorker.register('sw.js', { scope: './' }).catch(function () {});
    } catch (e) {}
  }

  /* ---------- напоминания о скором выезде ----------
     Раз за сессию проверяем поездки текущего пользователя и создаём
     уведомление за 90 минут до выезда. Дубликаты отсекаем по ключу. */
  function scheduleDepartureReminders() {
    var me = PP.store.currentUser();
    if (!me) return;
    var lang = PP.i18n.get();
    var now = Date.now();
    var seen = {};
    try { seen = JSON.parse(localStorage.getItem('pp.reminded') || '{}'); } catch (e) {}

    function routeOf(ride) {
      return PP.places.labelById(ride.fromId, lang) + ' \u2192 ' + PP.places.labelById(ride.toId, lang);
    }
    function consider(ride) {
      if (!ride || ride.status !== 'open') return;
      var dt = new Date(ride.departAt).getTime() - now;
      if (dt < 0 || dt > 90 * 60000) return;
      var key = me.id + ':' + ride.id;
      if (seen[key]) return;
      seen[key] = 1;
      PP.store.notify(me.id, 'soon', {
        route: routeOf(ride), time: PP.util.hhmm(ride.departAt)
      });
    }

    PP.store.where('rides', function (r) { return r.driverId === me.id; }).forEach(consider);
    PP.store.where('bookings', function (b) {
      return b.passengerId === me.id && (b.status === 'accepted' || b.status === 'pending');
    }).forEach(function (b) { consider(PP.store.find('rides', b.rideId)); });

    try { localStorage.setItem('pp.reminded', JSON.stringify(seen)); } catch (e) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else boot();
})(window.PP);
