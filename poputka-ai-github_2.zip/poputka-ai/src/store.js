/* ==========================================================
   Store — data access layer
   Единая точка доступа к данным. Сейчас за ней стоит
   localStorage-адаптер; чтобы перейти на Supabase/Firebase,
   достаточно заменить объект `adapter` — API остаётся тем же.
   ========================================================== */
(function (PP) {
  'use strict';
  var U = PP.util;
  var NS = 'pp.db.v1';
  var SESSION = 'pp.session';
  var SETTINGS = 'pp.settings';

  var COLLECTIONS = ['users', 'rides', 'bookings', 'messages', 'ratings',
                     'reports', 'bans', 'blocks', 'adminLogs', 'notifications'];

  /* Аккаунты основателей закреплены в коде: реальной инфраструктуры прав нет,
     но роль должна восстанавливаться при любом входе с этих адресов. */
  var FOUNDER_EMAILS = ['yldzhasan29@gmail.com', 'yigitcanisik04@gmail.com'];
  var MAX_ADMINS = 5;

  /* ---------- low-level adapter (swap me for Supabase) ---------- */
  var memory = null;

  var adapter = {
    load: function () {
      if (memory) return memory;
      var raw = null;
      try { raw = localStorage.getItem(NS); } catch (e) {}
      if (raw) {
        try { memory = JSON.parse(raw); } catch (e) { memory = null; }
      }
      if (!memory || !memory.users) memory = emptyDb();
      COLLECTIONS.forEach(function (c) { if (!Array.isArray(memory[c])) memory[c] = []; });
      return memory;
    },
    save: function () {
      try { localStorage.setItem(NS, JSON.stringify(memory)); } catch (e) {}
      emit();
    },
    wipe: function () {
      memory = null;
      try { localStorage.removeItem(NS); } catch (e) {}
    }
  };

  function emptyDb() {
    var db = { _v: 1 };
    COLLECTIONS.forEach(function (c) { db[c] = []; });
    return db;
  }

  /* ---------- reactive ---------- */
  var subs = [];
  function subscribe(fn) { subs.push(fn); return function () { subs = subs.filter(function (f) { return f !== fn; }); }; }
  function emit() { subs.slice().forEach(function (f) { try { f(); } catch (e) { console.error(e); } }); }

  /* ---------- generic ---------- */
  function all(col) { return adapter.load()[col].slice(); }
  function find(col, id) {
    var list = adapter.load()[col];
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }
  function where(col, pred) { return adapter.load()[col].filter(pred); }
  function insert(col, obj) {
    var db = adapter.load();
    if (!obj.id) obj.id = U.uid(col.slice(0, 2));
    if (!obj.createdAt) obj.createdAt = new Date().toISOString();
    db[col].push(obj);
    adapter.save();
    return obj;
  }
  function update(col, id, patch) {
    var row = find(col, id);
    if (!row) return null;
    Object.assign(row, patch);
    adapter.save();
    return row;
  }
  function remove(col, id) {
    var db = adapter.load();
    db[col] = db[col].filter(function (r) { return r.id !== id; });
    adapter.save();
  }

  /* ---------- session ---------- */
  function currentUserId() {
    try {
      return sessionStorage.getItem(SESSION) || localStorage.getItem(SESSION) || null;
    } catch (e) { return null; }
  }
  function currentUser() {
    var id = currentUserId();
    return id ? find('users', id) : null;
  }
  /* remember === true — сессия переживает закрытие вкладки (localStorage),
     иначе живёт только до конца вкладки (sessionStorage). Выход стирает обе. */
  function signIn(userId, remember) {
    try {
      localStorage.removeItem(SESSION);
      sessionStorage.removeItem(SESSION);
      (remember ? localStorage : sessionStorage).setItem(SESSION, userId);
    } catch (e) {}
    emit();
    return find('users', userId);
  }
  function signOut() {
    try {
      localStorage.removeItem(SESSION);
      sessionStorage.removeItem(SESSION);
    } catch (e) {}
    emit();
  }

  /* ---------- settings (AI provider etc.) ---------- */
  var defaultSettings = {
    provider: 'off',           // off | groq | gemini
    apiKey: '',
    model: '',
    autoTranslate: true
  };
  function getSettings() {
    var raw = null;
    try { raw = localStorage.getItem(SETTINGS); } catch (e) {}
    var s = defaultSettings;
    if (raw) { try { s = Object.assign({}, defaultSettings, JSON.parse(raw)); } catch (e) {} }
    return s;
  }
  function setSettings(patch) {
    var s = Object.assign({}, getSettings(), patch);
    try { localStorage.setItem(SETTINGS, JSON.stringify(s)); } catch (e) {}
    emit();
    return s;
  }

  /* ---------- domain helpers ---------- */
  function userStats(userId) {
    var rs = where('ratings', function (r) { return r.toUserId === userId; });
    var sum = rs.reduce(function (a, r) { return a + r.stars; }, 0);
    var asDriver = where('rides', function (r) { return r.driverId === userId && r.status === 'completed'; }).length;
    var asPassenger = where('bookings', function (b) {
      return b.passengerId === userId && b.status === 'completed';
    }).length;
    return {
      count: rs.length,
      avg: rs.length ? U.round1(sum / rs.length) : 0,
      trips: asDriver + asPassenger,
      asDriver: asDriver,
      asPassenger: asPassenger,
      reviews: rs.sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); })
    };
  }

  function rideSeatsTaken(rideId) {
    return where('bookings', function (b) {
      return b.rideId === rideId && (b.status === 'accepted' || b.status === 'completed');
    }).reduce(function (a, b) { return a + (b.seats || 1); }, 0);
  }
  function rideSeatsLeft(ride) {
    return Math.max(0, (ride.seats || 0) - rideSeatsTaken(ride.id));
  }

  function threadId(rideId, passengerId) { return rideId + '::' + passengerId; }

  function threadsFor(userId) {
    var out = [];
    var seen = {};
    where('bookings', function (b) { return true; }).forEach(function (b) {
      var ride = find('rides', b.rideId);
      if (!ride) return;
      if (b.passengerId !== userId && ride.driverId !== userId) return;
      var tid = threadId(b.rideId, b.passengerId);
      if (seen[tid]) return;
      seen[tid] = true;
      var other = b.passengerId === userId ? ride.driverId : b.passengerId;
      var msgs = where('messages', function (m) { return m.threadId === tid; })
        .sort(function (a, b2) { return new Date(a.createdAt) - new Date(b2.createdAt); });
      out.push({
        id: tid, rideId: b.rideId, bookingId: b.id,
        ride: ride, booking: b,
        otherId: other, other: find('users', other),
        messages: msgs,
        last: msgs.length ? msgs[msgs.length - 1] : null
      });
    });
    out.sort(function (a, b) {
      var ta = a.last ? new Date(a.last.createdAt) : new Date(a.ride.createdAt || 0);
      var tb = b.last ? new Date(b.last.createdAt) : new Date(b.ride.createdAt || 0);
      return tb - ta;
    });
    return out;
  }

  /* ---------- прочитанные переписки ----------
     Отметки хранятся отдельно от данных: { userId: { threadId: ISO-время } } */
  var READS = 'pp.reads';
  function allReads() {
    try { return JSON.parse(localStorage.getItem(READS) || '{}') || {}; }
    catch (e) { return {}; }
  }
  function markRead(userId, tid) {
    if (!userId || !tid) return;
    var r = allReads();
    r[userId] = r[userId] || {};
    r[userId][tid] = new Date().toISOString();
    try { localStorage.setItem(READS, JSON.stringify(r)); } catch (e) {}
    emit();
  }
  function isUnread(userId, th) {
    if (!th || !th.last) return false;
    if (th.last.senderId === userId) return false;
    var r = allReads()[userId] || {};
    var seenAt = r[th.id];
    if (!seenAt) return true;
    return new Date(th.last.createdAt) > new Date(seenAt);
  }
  function unreadCount(userId) {
    if (!userId) return 0;
    return threadsFor(userId).filter(function (th) { return isUnread(userId, th); }).length;
  }

  /* ---------- каскадные удаления ----------
     Поездку и бронь нельзя удалить «наполовину»: вместе с ними уходят
     связанные брони и сообщения, иначе в чатах остаются осиротевшие ветки. */
  function deleteRide(rideId) {
    var db = adapter.load();
    var bookings = db.bookings.filter(function (b) { return b.rideId === rideId; });
    var tids = bookings.map(function (b) { return threadId(rideId, b.passengerId); });
    db.messages = db.messages.filter(function (m) { return tids.indexOf(m.threadId) < 0; });
    db.bookings = db.bookings.filter(function (b) { return b.rideId !== rideId; });
    db.rides = db.rides.filter(function (r) { return r.id !== rideId; });
    adapter.save();
  }
  function cancelBooking(bookingId) {
    var db = adapter.load();
    var bk = null;
    db.bookings.forEach(function (b) { if (b.id === bookingId) bk = b; });
    if (!bk) return;
    var tid = threadId(bk.rideId, bk.passengerId);
    db.messages = db.messages.filter(function (m) { return m.threadId !== tid; });
    db.bookings = db.bookings.filter(function (b) { return b.id !== bookingId; });
    adapter.save();
  }

  /* ==========================================================
     Роли и права
     ========================================================== */
  function isFounder(u) {
    return !!u && FOUNDER_EMAILS.indexOf(String(u.email || '').toLowerCase()) >= 0;
  }
  function roleOf(u) {
    if (!u) return 'guest';
    if (isFounder(u)) return 'founder';
    return u.role === 'admin' ? 'admin' : 'user';
  }
  function isStaff(u) { var r = roleOf(u); return r === 'founder' || r === 'admin'; }
  function can(u, perm) {
    if (!u) return false;
    if (isFounder(u)) return true;
    if (roleOf(u) !== 'admin') return false;
    if (perm === 'logs') return false;           /* журнал — только основателям */
    return !!(u.perms && u.perms[perm]);
  }
  function admins() { return where('users', function (u) { return roleOf(u) === 'admin'; }); }
  function founders() { return where('users', function (u) { return isFounder(u); }); }

  function makeAdmin(userId, perms, byId) {
    if (admins().length >= MAX_ADMINS) return { ok: false, reason: 'limit' };
    update('users', userId, { role: 'admin', perms: perms || { users: true, reports: true, bans: false } });
    logAction(byId, 'make_admin', 'user', userId, JSON.stringify(perms || {}));
    return { ok: true };
  }
  function removeAdmin(userId, byId) {
    update('users', userId, { role: 'user', perms: null });
    logAction(byId, 'remove_admin', 'user', userId, '');
  }
  function setPerms(userId, perms, byId) {
    update('users', userId, { perms: perms });
    logAction(byId, 'set_perms', 'user', userId, JSON.stringify(perms));
  }

  /* ==========================================================
     Журнал действий администраторов (виден только основателям)
     ========================================================== */
  function logAction(adminId, action, targetType, targetId, detail) {
    insert('adminLogs', {
      id: U.uid('lg'), adminId: adminId, action: action,
      targetType: targetType, targetId: targetId, detail: detail || ''
    });
  }
  function logs() {
    return all('adminLogs').sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
  }

  /* ==========================================================
     Блокировки: предупреждение → временная → постоянная
     ========================================================== */
  function banUser(userId, level, reason, days, byId) {
    var until = null;
    if (level === 'temp') {
      var d = new Date();
      d.setDate(d.getDate() + (parseInt(days, 10) || 7));
      until = d.toISOString();
    }
    var ban = insert('bans', {
      id: U.uid('bn'), userId: userId, level: level, reason: reason || '',
      byAdminId: byId, until: until, lifted: false,
      appeal: null
    });
    logAction(byId, 'ban_' + level, 'user', userId, reason || '');
    notify(userId, 'ban', {});
    return ban;
  }
  function activeBan(userId) {
    var list = where('bans', function (b) { return b.userId === userId && !b.lifted; });
    var now = Date.now();
    var out = null;
    list.forEach(function (b) {
      if (b.level === 'warning') return;
      if (b.level === 'temp' && b.until && new Date(b.until).getTime() < now) return;
      out = b;
    });
    return out;
  }
  function lastWarning(userId) {
    var list = where('bans', function (b) { return b.userId === userId && b.level === 'warning' && !b.lifted; });
    return list.length ? list[list.length - 1] : null;
  }
  function liftBan(banId, byId) {
    var b = find('bans', banId);
    if (!b) return;
    update('bans', banId, { lifted: true });
    logAction(byId, 'unban', 'user', b.userId, '');
  }
  function appealBan(banId, text) {
    var b = find('bans', banId);
    if (!b) return;
    update('bans', banId, { appeal: { text: text, at: new Date().toISOString(), status: 'new' } });
  }
  function resolveAppeal(banId, accept, byId) {
    var b = find('bans', banId);
    if (!b || !b.appeal) return;
    var ap = Object.assign({}, b.appeal, { status: accept ? 'accepted' : 'rejected' });
    update('bans', banId, { appeal: ap, lifted: accept ? true : b.lifted });
    logAction(byId, accept ? 'appeal_accept' : 'appeal_reject', 'user', b.userId, '');
  }

  /* ==========================================================
     Жалобы и персональные блокировки
     ========================================================== */
  function addReport(fromId, targetId, rideId, reason, text) {
    var r = insert('reports', {
      id: U.uid('rp'), fromUserId: fromId, targetUserId: targetId,
      rideId: rideId || null, reason: reason, text: text || '', status: 'new'
    });
    return r;
  }
  function reviewReport(reportId, byId, dismissed) {
    update('reports', reportId, { status: dismissed ? 'dismissed' : 'reviewed' });
    logAction(byId, dismissed ? 'report_dismiss' : 'report_review', 'report', reportId, '');
  }
  function blockUser(userId, targetId) {
    if (isBlocked(userId, targetId)) return;
    insert('blocks', { id: U.uid('bl'), userId: userId, blockedId: targetId });
  }
  function unblockUser(userId, targetId) {
    var db = adapter.load();
    db.blocks = db.blocks.filter(function (b) { return !(b.userId === userId && b.blockedId === targetId); });
    adapter.save();
  }
  function isBlocked(userId, targetId) {
    return where('blocks', function (b) { return b.userId === userId && b.blockedId === targetId; }).length > 0;
  }
  function blockedIds(userId) {
    return where('blocks', function (b) { return b.userId === userId; }).map(function (b) { return b.blockedId; });
  }

  /* ==========================================================
     Уведомления
     ========================================================== */
  function notify(userId, type, vars) {
    if (!userId) return;
    return insert('notifications', {
      id: U.uid('nt'), userId: userId, type: type, vars: vars || {}, read: false
    });
  }
  function notificationsFor(userId) {
    return where('notifications', function (n) { return n.userId === userId; })
      .sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
  }
  function unreadNotifications(userId) {
    return where('notifications', function (n) { return n.userId === userId && !n.read; }).length;
  }
  function markNotificationsRead(userId) {
    var db = adapter.load();
    db.notifications.forEach(function (n) { if (n.userId === userId) n.read = true; });
    adapter.save();
  }

  /* ==========================================================
     Доверие и «проверенный водитель» (самодекларация)
     ========================================================== */
  function isVerifiedDriver(u) {
    return !!(u && u.license && u.plate && u.carModel);
  }
  function trustOf(userId) {
    var u = find('users', userId);
    var st = userStats(userId);
    var tripScore = Math.min(1, st.trips / 10) * 0.40;
    var rateScore = (st.count ? U.clamp((st.avg - 3) / 2, 0, 1) : 0.5) * 0.40;
    var verScore = (isVerifiedDriver(u) ? 1 : 0) * 0.20;
    var score = tripScore + rateScore + verScore;
    var ban = u ? activeBan(u.id) : null;
    if (ban) score = 0;
    var level = score >= 0.85 ? 'top' : score >= 0.60 ? 'high' : score >= 0.35 ? 'ok' : 'new';
    return { score: score, level: level, verified: isVerifiedDriver(u) };
  }

  PP.store = {
    COLLECTIONS: COLLECTIONS,
    all: all, find: find, where: where, insert: insert, update: update, remove: remove,
    subscribe: subscribe, emit: emit,
    currentUser: currentUser, currentUserId: currentUserId, signIn: signIn, signOut: signOut,
    getSettings: getSettings, setSettings: setSettings,
    userStats: userStats, rideSeatsLeft: rideSeatsLeft, rideSeatsTaken: rideSeatsTaken,
    FOUNDER_EMAILS: FOUNDER_EMAILS, MAX_ADMINS: MAX_ADMINS,
    isFounder: isFounder, roleOf: roleOf, isStaff: isStaff, can: can,
    admins: admins, founders: founders, makeAdmin: makeAdmin, removeAdmin: removeAdmin, setPerms: setPerms,
    logAction: logAction, logs: logs,
    banUser: banUser, activeBan: activeBan, lastWarning: lastWarning, liftBan: liftBan,
    appealBan: appealBan, resolveAppeal: resolveAppeal,
    addReport: addReport, reviewReport: reviewReport,
    blockUser: blockUser, unblockUser: unblockUser, isBlocked: isBlocked, blockedIds: blockedIds,
    notify: notify, notificationsFor: notificationsFor,
    unreadNotifications: unreadNotifications, markNotificationsRead: markNotificationsRead,
    isVerifiedDriver: isVerifiedDriver, trustOf: trustOf,
    threadId: threadId, threadsFor: threadsFor, unreadCount: unreadCount,
    markRead: markRead, isUnread: isUnread,
    deleteRide: deleteRide, cancelBooking: cancelBooking,
    _adapter: adapter, _empty: emptyDb,
    isEmpty: function () { return adapter.load().users.length === 0; },
    replaceAll: function (db) {
      memory = Object.assign(emptyDb(), db);
      adapter.save();
    },
    wipe: function () { adapter.wipe(); }
  };
})(window.PP);
