/* ==========================================================
   Matching engine
   score = 0.45·маршрут + 0.32·время + 0.23·доверие
   Доверие включает рейтинг, число завершённых поездок и
   заполненность данных водителя — так проверенные водители
   поднимаются в выдаче, а новые и проблемные опускаются.
   Объяснение «почему эта поездка» строится по шаблонам,
   без обращения к LLM — быстро, дёшево и предсказуемо.
   ========================================================== */
(function (PP) {
  'use strict';
  var U = PP.util, S = PP.store, P = PP.places;

  var W_ROUTE = 0.45, W_TIME = 0.32, W_TRUST = 0.23;
  var LEG_KM_ZERO = 9;   /* отклонение, при котором участок даёт 0 */
  var LUG_RANK = { none: 0, small: 1, large: 2 };

  function legScore(a, b) {
    var d = U.haversine(a, b);
    return { s: U.clamp(1 - d / LEG_KM_ZERO, 0, 1), km: d };
  }

  function ridePrefs(ride) {
    return ride.prefs || { lug: 'small', smoke: false, access: false, women: false };
  }

  function scoreRide(ride, q) {
    var from = P.byId[ride.fromId], to = P.byId[ride.toId];
    var qFrom = P.byId[q.fromId], qTo = P.byId[q.toId];
    if (!from || !to || !qFrom || !qTo) return null;

    var lf = legScore(qFrom, from), lt = legScore(qTo, to);
    var route = (lf.s + lt.s) / 2;

    var dt = Math.abs(U.minutesOfDay(ride.departAt) - q.minutes);
    var flex = q.flex || 15;
    var time;
    if (dt <= flex) time = 1 - 0.35 * (dt / Math.max(1, flex));
    else time = Math.max(0, 0.65 * (1 - (dt - flex) / 75));

    var st = S.userStats(ride.driverId);
    var trust = S.trustOf(ride.driverId);

    var total = W_ROUTE * route + W_TIME * time + W_TRUST * trust.score;

    return {
      ride: ride,
      score: total,
      pct: Math.round(U.clamp(total, 0, 1) * 100),
      routePct: Math.round(route * 100),
      dt: dt,
      seatsLeft: S.rideSeatsLeft(ride),
      driver: S.find('users', ride.driverId),
      stats: st,
      trust: trust,
      prefs: ridePrefs(ride),
      sameFrom: ride.fromId === q.fromId,
      sameTo: ride.toId === q.toId,
      kmFrom: U.round1(lf.km), kmTo: U.round1(lt.km)
    };
  }

  /* q = {fromId,toId,dayOffset,minutes,flex,seats,sort,lang,me,
          priceMax,lug,noSmoke,needAccess,womenOnly} */
  function search(q) {
    var now = Date.now();
    var me = q.me || null;
    var blocked = me ? S.blockedIds(me.id) : [];
    var isWoman = !!me && me.gender === 'female';

    var rides = S.where('rides', function (r) {
      if (r.status !== 'open') return false;
      if (U.dayOffset(r.departAt) !== q.dayOffset) return false;
      if (new Date(r.departAt).getTime() < now - 30 * 60000) return false;
      if (q.excludeDriver && r.driverId === q.excludeDriver) return false;
      if (S.rideSeatsLeft(r) < (q.seats || 1)) return false;

      /* заблокированные и забаненные водители из выдачи убираются */
      if (blocked.indexOf(r.driverId) >= 0) return false;
      if (S.activeBan(r.driverId)) return false;

      var pf = ridePrefs(r);

      /* «только для женщин»: поездку видят и бронируют только женщины */
      if (pf.women && !isWoman) return false;
      if (q.womenOnly && !pf.women) return false;

      if (q.priceMax && (r.price || 0) > q.priceMax) return false;
      if (q.lug && LUG_RANK[pf.lug] < LUG_RANK[q.lug]) return false;
      if (q.needAccess && !pf.access) return false;
      if (q.noSmoke && pf.smoke) return false;
      return true;
    });

    var out = [];
    rides.forEach(function (r) {
      var m = scoreRide(r, q);
      if (m && m.score > 0.12) out.push(m);
    });

    var sort = q.sort || 'match';
    out.sort(function (a, b) {
      if (sort === 'time') return new Date(a.ride.departAt) - new Date(b.ride.departAt);
      if (sort === 'rating') return (b.stats.avg || 0) - (a.stats.avg || 0);
      if (sort === 'trust') return b.trust.score - a.trust.score;
      if (sort === 'price') return (a.ride.price || 0) - (b.ride.price || 0);
      return b.score - a.score;
    });
    return out;
  }

  /* Шаблонные объяснения — локализуются через i18n */
  function reasons(m, q) {
    var t = PP.i18n.t, out = [];

    if (m.dt === 0) out.push({ icon: 'clock', text: t('m_time_exact') });
    else if (m.dt <= 10) out.push({ icon: 'clock', text: t('m_time_close', { n: m.dt }) });
    else out.push({ icon: 'clock', text: t('m_time_window', { n: m.dt }) });

    if (m.sameFrom && m.sameTo) out.push({ icon: 'route', text: t('m_route_same') });
    else if (m.routePct >= 55) out.push({ icon: 'route', text: t('m_route_near', { n: m.routePct }) });
    else out.push({ icon: 'route', text: t('m_route_far') });

    if (m.stats.count) out.push({ icon: 'star', text: t('m_rating', { n: m.stats.avg }) });
    else out.push({ icon: 'star', text: t('m_new_driver') });

    if (m.trust.verified) out.push({ icon: 'shield', text: t('v_verified') });
    else out.push({ icon: 'users', text: t('m_seats', { n: m.seatsLeft }) });

    if (q && q.lang && m.driver && m.driver.lang === q.lang) {
      out.push({ icon: 'globe', text: t('m_lang') });
    }
    return out;
  }

  PP.matching = { search: search, scoreRide: scoreRide, reasons: reasons, LUG_RANK: LUG_RANK };
})(window.PP);
